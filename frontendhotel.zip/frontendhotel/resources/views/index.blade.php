<!DOCTYPE html>
<html lang="en">

<head>
  <title>Test Hoteles</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.24.0/axios.min.js" integrity="sha512-u9akINsQsAkG9xjc1cnGF4zw5TFDwkxuc9vUp5dltDWYCSmyd0meygbvgXrlc/z7/o4a19Fb5V0OUE58J7dcyw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.24.0/axios.js" integrity="sha512-RT3IJsuoHZ2waemM8ccCUlPNdUuOn8dJCH46N3H2uZoY7swMn1Yn7s56SsE2UBMpjpndeZ91hm87TP1oU6ANjQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="{{ asset('js/index.js') }}"></script>
</head>

<body>

  <nav class="navbar navbar-default">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" href="#">HOTEL DECAMERON</a>
      </div>
      <ul class="nav navbar-nav">
        <li class="active"><a href="#" data-toggle="modal" data-target="#myModal" id="btncrearhotel">Registrar Hotel</a></li>
      </ul>
    </div>
  </nav>

  <div class="container">
    <h3>Master de Hoteles</h3>
    <p>Registre el hotel y despues configure las habitaciones para cada hotel.</p>

    <table class="table table-striped success">
      <thead>
        <tr>
          <th>Nit</th>
          <th>Nombre del Hotel</th>
          <th>Direccion</th>
          <th>Capacidad</th>
          <th>Opciones</th>
        </tr>
      </thead>
      <tbody id="mostrarhoteles">
        <tr>
          <td colspan="5">Cargando datos..</td>

        </tr>

      </tbody>

  </div>

  <div class="modal fade" id="ModalListaHabitacion" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Lista de habitaciones</h4>
        </div>
        <div class="modal-body" id="mostrarhabitaciones">
          Cargando datos..
        </div>
        <div class="modal-footer">

          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>

    </div>
  </div>

  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" id="titulo">Crear Hotel</h4>
        </div>
        <div class="modal-body">
          <form id="crearhotel">
            <div class="row">
              <div class="col-md-12">
                <label for="">Nit</label>
                <input type="text" name="nit" id="nit" class="form-control">
                <input type="hidden" name="id" id="id" class="form-control">
              </div>
              <div class="col-md-12">
                <label for="">Nombre del Hotel</label>
                <input type="text" name="nombre" id="nombre" class="form-control">
              </div>
              <div class="col-md-12">
                <label for="">Direccion</label>
                <input type="text" name="direccion" id="direccion" class="form-control">
              </div>
              <div class="col-md-12">
                <label for="">Cantidad de Habitaciones</label>
                <input type="text" name="numero" id="numero" class="form-control">
              </div>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-success" id="btn_save">Guardar </button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>

    </div>
  </div>

  <div class="modal fade" id="ModalHabitacion" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Configurar Habitación</h4>
        </div>
        <div class="modal-body">
          <form id="configurar">
            <div class="row">
              <div class="col-md-12">
                <label for="">Sucursal</label>
                <input type="text" name="sucursal" id="sucursal" class="form-control" readonly>
              </div>
              <div class="col-md-12">
                <label for="">Tipo Habitación</label>

                <select name="tipo" id="tipo" class="form-control">

                </select>
              </div>
              <div class="col-md-12">
                <label for="">Acomodación</label>
                <select name="aco" id="aco" class="form-control">

                </select>
              </div>
              <div class="col-md-12">
                <label for="">Numero de Habitacion</label>
                <input type="text" name="numero" id="numero" class="form-control">
              </div>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-success" id="btn_save_hab">Guardar Habitación </button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
        </div>
      </div>

    </div>
  </div>

</body>

</html>