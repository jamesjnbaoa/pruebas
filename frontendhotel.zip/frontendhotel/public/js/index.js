$(document).ready(function () {
    $("#btn_save").on("click", function (e) {
        var id = document.getElementById("id").value;
        if (id == "") {
            saveHotel(e);
        } else {
            updateHotel(e);
        }
    });
    $("#btn_save_hab").on("click", function (e) {
        saveHab(e);
    });
    $("#btncrearhotel").on("click", function (e) {
        document.getElementById("titulo").innerHTML = "Crear Hotel";
        document.getElementById("nit").value = "";
        document.getElementById("id").value = "";
        document.getElementById("nombre").value = "";
        document.getElementById("direccion").value = "";
        document.getElementById("numero").value = "";
    });
    mostrarHoteles();
});
const url = "http://hotel.ingeniosvirtuales.com/";
const token = "testhotel";
function saveHotel(e) {
    e.preventDefault();
    let form = $("#crearhotel")[0];
    let datos = new FormData(form);

    axios
        .post(url + "api/AddSucursal", datos, {
            headers: {
                Authorization: `${token}`,
                Accept: "application/json",
            },
        })
        .then(
            (res) => {
                console.log(res.data.Radicado);
                console.log(res.data);
                if (res.data.Radicado) {
                    Swal.fire({
                        title: "Genial!",
                        text: res.data.Msj,
                        icon: "success",
                        confirmButtonText: "Ok",
                    });
                    document.getElementById("crearhotel").reset();
                    mostrarHoteles();
                } else {
                    Swal.fire({
                        title: "Ups!",
                        text: res.data.Msj,
                        icon: "danger",
                        confirmButtonText: "Ok",
                    });
                }
            },
            (error) => {
                Swal.fire({
                    title: "Error!",
                    text: "Ocurrio un error al registrar los datos",
                    icon: "error",
                    confirmButtonText: "Cool",
                });
            }
        );
}
function updateHotel(e) {
    e.preventDefault();
    let form = $("#crearhotel")[0];
    let datos = new FormData(form);

    axios
        .post(url + "api/UpSucursal", datos, {
            headers: {
                Authorization: `${token}`,
                Accept: "application/json",
            },
        })
        .then(
            (res) => {
                console.log(res.data.Radicado);
                console.log(res.data);
                if (res.data.Radicado) {
                    Swal.fire({
                        title: "Genial!",
                        text: res.data.Msj,
                        icon: "success",
                        confirmButtonText: "Ok",
                    });
                    document.getElementById("crearhotel").reset();
                    mostrarHoteles();
                } else {
                    Swal.fire({
                        title: "Ups!",
                        text: res.data.Msj,
                        icon: "danger",
                        confirmButtonText: "Ok",
                    });
                }
            },
            (error) => {
                Swal.fire({
                    title: "Error!",
                    text: "Ocurrio un error al registrar los datos",
                    icon: "error",
                    confirmButtonText: "Cool",
                });
            }
        );
}
   
function mostrarHoteles() {
    axios
        .get(url + "api/Sucursales", {
            headers: {
                Authorization: `${token}`,
                Accept: "application/json",
            },
        })
        .then(
            (res) => {
                let f;
                var filas = "";
                for (var i = 0; i < res.data.length; i++) {
                    //console.log(res.data[i].sucursal_id);
                    f = res.data[i];
                    btn =
                        '<button onclick="VerData(' +
                        f.sucursal_id +
                        ')" data-toggle="modal" data-target="#ModalHabitacion">+ Habitaciones</button>';
                    btn4 =
                        '<button onclick="VerDataHab(' +
                        f.sucursal_id +
                        ')" data-toggle="modal" data-target="#ModalListaHabitacion">Ver Habitaciones</button>';
                    btn2 =
                        '<button  onclick="VerHotel(' +
                        f.sucursal_id +
                        ')" data-toggle="modal" data-target="#myModal">Editar</button>';
                    btn3 =
                        '<button onclick="DelHotel(' +
                        f.sucursal_id +
                        ')">Eliminar</button>';
                    filas +=
                        "<tr><td>" +
                        f.suc_nit +
                        "</td><td>" +
                        f.suc_name +
                        "</td><td>" +
                        f.suc_dir +
                        "</td><td>" +
                        f.suc_hab +
                        "</td><td>" +
                        btn +
                        " " +
                        btn4 +
                        "  " +
                        btn2 +
                        " " +
                        btn3 +
                        "</td></tr>";
                }
                document.getElementById("mostrarhoteles").innerHTML = filas;
            },
            (error) => {
                Swal.fire({
                    title: "Error!",
                    text: "Ocurrio un error al mostrar los datos",
                    icon: "error",
                    confirmButtonText: "Cool",
                });
            }
        );
}

function VerHotel(id) {
    axios
        .get(url + "api/Sucursales/" + id, {
            headers: {
                Authorization: `${token}`,
                Accept: "application/json",
            },
        })
        .then(
            (res) => {
                document.getElementById("id").value = res.data.sucursal_id;
                document.getElementById("nit").value = res.data.suc_nit;
                document.getElementById("nombre").value = res.data.suc_name;
                document.getElementById("direccion").value = res.data.suc_dir;
                document.getElementById("numero").value = res.data.suc_hab;
                document.getElementById("titulo").innerHTML = "Editar Hotel";
            },
            (error) => {
                Swal.fire({
                    title: "Error!",
                    text: "Ocurrio un error al mostrar los datos",
                    icon: "error",
                    confirmButtonText: "Cool",
                });
            }
        );
}
function VerDataHab(dato) {
    axios
        .get(url + "api/VerHabitaciones/" + dato, {
            headers: {
                Authorization: `${token}`,
                Accept: "application/json",
            },
        })
        .then(
            (res) => {
                var fi;
                var filash =
                    '<table class="table"><tr><th>Habitacion</th><th>Tipo</th><th>Acomodacion</th><th>Borrar</th>';
                for (var i = 0; i < res.data.length; i++) {
                    console.log(res.data[i].hab_id);
                    fi = res.data[i];
                    btn =
                        '<button onclick="DelHab(' +
                        fi.hab_id +
                        "," +
                        dato +
                        ')">- Borrar</button>';

                    filash +=
                        "<tr><td>" +
                        fi.hab_numero +
                        "</td><td>" +
                        fi.tipo_name +
                        "</td><td>" +
                        fi.aco_name +
                        "</td><td>" +
                        btn +
                        "</td></tr>";
                }
                filash += "</table>";
                document.getElementById("mostrarhabitaciones").innerHTML =
                    filash;
            },
            (error) => {
                Swal.fire({
                    title: "Error!",
                    text: "Ocurrio un error al mostrar los datos",
                    icon: "error",
                    confirmButtonText: "Cool",
                });
            }
        );
}
function DelHab(dato, id) {
    Swal.fire({
        title: "Estas seguro?",
        text: "No podras revertir el proceso!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Si, Borrar!",
    }).then((result) => {
        if (result.isConfirmed) {
            axios
                .delete(url + "api/Habitaciones/" + dato, {
                    headers: {
                        Authorization: `${token}`,
                        Accept: "application/json",
                    },
                })
                .then(
                    (res) => {
                        Swal.fire({
                            title: "Borrado!",
                            text: res.data.Msj,
                            icon: "success",
                            confirmButtonText: "Ok",
                        });
                        VerDataHab(id);
                    },
                    (error) => {
                        Swal.fire({
                            title: "Error!",
                            text: "Ocurrio un error al borrar el dato",
                            icon: "error",
                            confirmButtonText: "Ok",
                        });
                    }
                );
        }
    });
}
function DelHotel(dato) {
    Swal.fire({
        title: "Estas seguro?",
        text: "No podras revertir el proceso!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Si, Borrar!",
    }).then((result) => {
        if (result.isConfirmed) {
            axios
                .delete(url + "api/Sucursales/" + dato, {
                    headers: {
                        Authorization: `${token}`,
                        Accept: "application/json",
                    },
                })
                .then(
                    (res) => {
                        Swal.fire({
                            title: "Borrado!",
                            text: res.data.Msj,
                            icon: "success",
                            confirmButtonText: "Ok",
                        });
                        mostrarHoteles();
                    },
                    (error) => {
                        Swal.fire({
                            title: "Error!",
                            text: "Ocurrio un error al borrar el dato",
                            icon: "error",
                            confirmButtonText: "Ok",
                        });
                    }
                );
        }
    });
}
function VerData(dato) {
    configurar.sucursal.value = dato;
    CargarTipo();
    CargarAcomodaciones();
}
function CargarTipo() {
    axios
        .get(url + "api/Tipos", {
            headers: {
                Authorization: `${token}`,
                Accept: "application/json",
            },
        })
        .then(
            (res) => {
                let f = res.data;
                console.log(res.data);
                filas = '<option value="">Seleccione el tipo</option>';
                for (var i = 0; i < f.length; i++) {
                    filas +=
                        '<option value="' +
                        f[i].tipo_id +
                        '">' +
                        f[i].tipo_name +
                        "</option>";
                }
                document.getElementById("tipo").innerHTML = filas;
            },
            (error) => {
                Swal.fire({
                    title: "Error!",
                    text: "Ocurrio un error al mostrar los datos",
                    icon: "error",
                    confirmButtonText: "Cool",
                });
            }
        );
}
function CargarAcomodaciones() {
    axios
        .get(url + "api/Acomodaciones", {
            headers: {
                Authorization: `${token}`,
                Accept: "application/json",
            },
        })
        .then(
            (res) => {
                let f = res.data;
                console.log(res.data);
                filas = '<option value="">Seleccione la acomodacion</option>';
                for (var i = 0; i < f.length; i++) {
                    filas +=
                        '<option value="' +
                        f[i].aco_id +
                        '">' +
                        f[i].aco_name +
                        "</option>";
                }
                document.getElementById("aco").innerHTML = filas;
            },
            (error) => {
                Swal.fire({
                    title: "Error!",
                    text: "Ocurrio un error al mostrar los datos",
                    icon: "error",
                    confirmButtonText: "Cool",
                });
            }
        );
}
function saveHab(e) {
    e.preventDefault();
    let form = $("#configurar")[0];
    let datos = new FormData(form);

    axios
        .post(url + "api/AddHabitacion", datos, {
            headers: {
                Authorization: `${token}`,
                Accept: "application/json",
            },
        })
        .then(
            (res) => {
                console.log(res.data.Radicado);
                console.log(res.data);
                if (res.data.Radicado) {
                    Swal.fire({
                        title: "Genial!",
                        text: res.data.Msj,
                        icon: "success",
                        confirmButtonText: "Ok",
                    });
                    document.getElementById("configurar").reset();
                    $("#ModalHabitacion").modal("hide");
                } else {
                    Swal.fire({
                        title: "Ups!",
                        text: res.data.Msj,
                        icon: "warning",
                        confirmButtonText: "Ok",
                    });
                }
            },
            (error) => {
                Swal.fire({
                    title: "Error!",
                    text: "Ocurrio un error al registrar los datos",
                    icon: "error",
                    confirmButtonText: "Ok",
                });
            }
        );
}
